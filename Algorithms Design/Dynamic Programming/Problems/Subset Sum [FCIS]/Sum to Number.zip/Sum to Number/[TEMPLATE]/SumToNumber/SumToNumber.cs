﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem
{
    // *****************************************
    // DON'T CHANGE CLASS OR FUNCTION NAME
    // YOU CAN ADD FUNCTIONS IF YOU NEED TO
    // *****************************************
    public static class SumToNumber
    {
        #region YOUR CODE IS HERE
        #region FUNCTION#1: Calculate the Value
        //Your Code is Here:
        //==================
        // <summary>
        /// Fill this function to check whether there's a subsequence numbers in the given array that sum up to the given value
        /// </summary>
        /// <param name="items">array of integers</param>
        /// <param name="N">array size </param>
        /// <param name="B">value to check against it</param>
        /// <returns>true if there's subsequence... false otherwise</returns>
        static public bool SolveValue(int[] items, int N, int B)
        {
            //REMOVE THIS LINE BEFORE START CODING
            throw new NotImplementedException();
        }
        #endregion

        #region FUNCTION#2: Construct the Solution
        //Your Code is Here:
        //==================
        // <summary>
        /// Fill this function to check whether there's a subsequence numbers in the given array that sum up to the given value
        /// </summary>
        /// <param name="items">array of integers</param>
        /// <param name="N">array size </param>
        /// <param name="B">value to check against it</param>
        /// <returns>if exists, return the numbers themselves whose sum equals to ‘B’ else, return null</returns>
        static public int[] ConstructSolution(int[] items, int N, int B)
        {
            //REMOVE THIS LINE BEFORE START CODING
            throw new NotImplementedException();
        }
        #endregion

        #endregion
    }
}
